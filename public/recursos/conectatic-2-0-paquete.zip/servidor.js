// ConectaTIC 2.0 · Servidor de aula LAN, sin dependencias externas.
// Ejecutar: node servidor.js
// Abrir: http://localhost:8787 y http://IP-DE-TU-PC:8787 desde celulares en la misma red.
'use strict';
const http=require('http'),fs=require('fs'),os=require('os'),path=require('path'),crypto=require('crypto');
const PORT=Number(process.env.PORT||8787), HOST='0.0.0.0';
const html=path.join(__dirname,'ConectaTIC_2_0_Acceso_Docente.html');
const sessions=new Map();
const teacherPIN=process.env.DOCENTE_PIN||String(crypto.randomInt(100000,1000000));
const tokens=new Set();
const attempts=new Map();
function authorized(req){let m=(req.headers.cookie||'').match(/(?:^|;\s*)ct_teacher=([a-f0-9]{64})(?:;|$)/);return !!(m&&tokens.has(m[1]))}
function setCookie(res,value){res.setHeader('Set-Cookie','ct_teacher='+value+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800')}

const clean=(x,n)=>String(x??'').trim().slice(0,n);
function reply(res,status,data,type='application/json; charset=utf-8'){
  res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Access-Control-Allow-Origin':'same-origin'});
  res.end(type.startsWith('application/json')?JSON.stringify(data):data);
}
const server=http.createServer((req,res)=>{
  let url;try{url=new URL(req.url,'http://localhost')}catch(e){return reply(res,400,{error:'URL inválida'})}
  if(req.method==='GET'&&(url.pathname==='/'||url.pathname==='/ConectaTIC_2_0_Acceso_Docente.html')){
    return fs.readFile(html,(e,b)=>e?reply(res,500,{error:'No se encuentra HTML'}):reply(res,200,b,'text/html; charset=utf-8'));
  }
  if(req.method==='GET'&&url.pathname==='/api/results'){
    if(!authorized(req))return reply(res,403,{error:'Acceso exclusivo del docente'});
    const code=clean(url.searchParams.get('session'),20);
    return reply(res,200,{items:(sessions.get(code)||[]).slice(-300)});
  }

  if(req.method==='POST'&&url.pathname==='/api/teacher/login'){
    const addr=req.socket.remoteAddress||'unknown';const now=Date.now();let x=attempts.get(addr)||{n:0,until:0};
    if(x.until>now)return reply(res,429,{error:'Demasiados intentos. Espera 2 minutos.'});
    let body='';req.on('data',c=>{body+=c;if(body.length>1000)req.destroy()});return req.on('end',()=>{
      let data;try{data=JSON.parse(body)}catch(e){return reply(res,400,{error:'Solicitud inválida'})}
      const supplied=String(data.pin||'');
      const ok=supplied.length===teacherPIN.length&&crypto.timingSafeEqual(Buffer.from(supplied),Buffer.from(teacherPIN));
      if(!ok){x.n++;if(x.n>=5){x={n:0,until:Date.now()+120000}}attempts.set(addr,x);return reply(res,401,{error:'PIN incorrecto'})}
      attempts.delete(addr);const token=crypto.randomBytes(32).toString('hex');tokens.add(token);setCookie(res,token);reply(res,200,{ok:true});
    });
  }
  if(req.method==='POST'&&url.pathname==='/api/teacher/logout'){
    let m=(req.headers.cookie||'').match(/(?:^|;\s*)ct_teacher=([a-f0-9]{64})(?:;|$)/);if(m)tokens.delete(m[1]);
    res.setHeader('Set-Cookie','ct_teacher=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return reply(res,200,{ok:true});
  }
  if(req.method==='POST'&&url.pathname==='/api/submit'){
    let body='';req.on('data',chunk=>{body+=chunk;if(body.length>3000)req.destroy()});
    return req.on('end',()=>{let v;try{v=JSON.parse(body)}catch(e){return reply(res,400,{error:'JSON inválido'})}
      const session=clean(v.session,20),alias=clean(v.alias,30),activity=clean(v.activity,40);
      if(!/^[a-zA-Z0-9_-]{3,20}$/.test(session)||!alias||!activity)return reply(res,400,{error:'Campos inválidos'});
      const item={session,alias,activity,answer:clean(v.answer,400),score:Number(v.score)||0,time:new Date().toISOString()};
      let list=sessions.get(session)||[];list.push(item);if(list.length>300)list.shift();sessions.set(session,list);
      reply(res,200,{ok:true});
    });
  }
  reply(res,404,{error:'Ruta no encontrada'});
});
server.listen(PORT,HOST,()=>{
 console.log('\nConectaTIC 2.0 — Aula LAN');
 console.log('Docente: http://localhost:'+PORT);
 console.log('\nPIN DOCENTE (NO COMPARTIR): '+teacherPIN+'\n');
 for(const arr of Object.values(os.networkInterfaces()))for(const i of arr||[])if(i.family==='IPv4'&&!i.internal)console.log('Celulares: http://'+i.address+':'+PORT);
 console.log('Mantén esta ventana abierta durante la clase. Ctrl+C para detener.');
 console.log('Datos en memoria: se borran al detener el servidor.\n');
});
